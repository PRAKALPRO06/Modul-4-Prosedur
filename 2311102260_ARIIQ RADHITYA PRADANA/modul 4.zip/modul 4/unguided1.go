package main

import (
	"fmt"
)

// Procedure untuk menghitung faktorial dari n
func mencariFaktorial(n int) int {
	if n == 0 {
		return 1
	}
	faktorial := 1
	for i := 1; i <= n; i++ {
		faktorial *= i
	}
	return faktorial
}

// Function untuk menghitung permutasi P(n, r)
func permutation(n int, r int) int {
	return mencariFaktorial(n) / mencariFaktorial(n-r)
}

// Function untuk menghitung kombinasi C(n, r)
func combination(n int, r int) int {
	return mencariFaktorial(n) / (mencariFaktorial(r) * mencariFaktorial(n-r))
}

func main() {
	var a, b, c, d int
	fmt.Print("Masukkan nilai a, b, c, d (pisahkan dengan spasi): ")
	fmt.Scan(&a, &b, &c, &d)

	// Validasi input
	if a < c || b < d {
		fmt.Println("Input tidak valid: a harus >= c dan b harus >= d")
		return
	}

	// Menghitung permutasi dan kombinasi
	permA := permutation(a, c)
	combA := combination(a, c)
	permB := permutation(b, d)
	combB := combination(b, d)

	// Menampilkan hasil
	fmt.Printf("Hasil Permutasi dan Kombinasi:\n")
	fmt.Printf("P(%d, %d) = %d\n", a, c, permA)
	fmt.Printf("C(%d, %d) = %d\n", a, c, combA)
	fmt.Printf("P(%d, %d) = %d\n", b, d, permB)
	fmt.Printf("C(%d, %d) = %d\n", b, d, combB)
}
