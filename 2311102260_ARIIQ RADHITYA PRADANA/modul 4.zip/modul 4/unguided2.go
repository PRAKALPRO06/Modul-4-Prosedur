package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strings"
)

// Prosedur hitungSkor menghitung jumlah soal yang diselesaikan dan total waktu yang dibutuhkan
func hitungSkor(waktu []int, soal *int, skor *int) {
	*soal = 0 // jumlah soal yang diselesaikan
	*skor = 0 // total waktu pengerjaan soal yang berhasil diselesaikan
	for _, w := range waktu {
		if w <= 300 {
			*soal++    // jika soal berhasil dikerjakan (<= 300 menit)
			*skor += w // tambahkan waktu pengerjaan ke skor
		}
	}
}

func main() {
	var pemenang string
	var maxSoal, minSkor int
	maxSoal = -1
	minSkor = math.MaxInt32

	reader := bufio.NewReader(os.Stdin) // Menggunakan bufio untuk pembacaan input yang lebih fleksibel

	for {
		fmt.Println("Masukkan nama dan waktu pengerjaan (ketik 'Selesai' untuk berhenti):")
		input, _ := reader.ReadString('\n') // Membaca input baris penuh
		input = strings.TrimSpace(input)    // Menghapus spasi atau karakter newline di akhir input

		// Periksa apakah inputnya "Selesai"
		if strings.ToLower(input) == "selesai" {
			break
		}

		// Cek apakah input kosong
		if input == "" {
			continue // lewati iterasi jika input kosong
		}

		// Pisahkan input menjadi bagian nama dan waktu pengerjaan
		parts := strings.Fields(input)
		if len(parts) != 9 {
			fmt.Println("Input tidak valid, masukkan nama dan 8 waktu pengerjaan soal.")
			continue
		}

		nama := parts[0] // Nama peserta
		var waktu [8]int

		// Parsing waktu pengerjaan
		for i := 0; i < 8; i++ {
			fmt.Sscanf(parts[i+1], "%d", &waktu[i])
		}

		// Hitung skor dan jumlah soal yang diselesaikan
		var soal, skor int
		hitungSkor(waktu[:], &soal, &skor)

		// Tentukan pemenang berdasarkan kriteria yang disebutkan
		if soal > maxSoal || (soal == maxSoal && skor < minSkor) {
			pemenang = nama
			maxSoal = soal
			minSkor = skor
		}
	}

	// Output pemenang
	if pemenang != "" {
		fmt.Printf("%s %d %d\n", pemenang, maxSoal, minSkor)
	} else {
		fmt.Println("Tidak ada peserta.")
	}
}
