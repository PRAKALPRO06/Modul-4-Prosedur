package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	var bilangan int
	var pesan string

	// Create a scanner to read input
	scanner := bufio.NewScanner(os.Stdin)

	// Read the integer
	fmt.Print("Masukkan bilangan (0, 1, 2): ")
	scanner.Scan() // Read the integer input
	fmt.Sscanf(scanner.Text(), "%d", &bilangan)

	// Read the string
	fmt.Print("Masukkan pesan: ")
	scanner.Scan() // Read the string input
	pesan = scanner.Text()

	// Call cetakPesan function
	cetakPesan(pesan, bilangan)
}

func cetakPesan(M string, flag int) {
	var jenis string
	if flag == 0 {
		jenis = "error"
	} else if flag == 1 {
		jenis = "warning"
	} else if flag == 2 {
		jenis = "informasi"
	} else {
		jenis = "unknown" // Handle invalid flag values
	}
	// Print message and type
	fmt.Println(M, jenis)
}
