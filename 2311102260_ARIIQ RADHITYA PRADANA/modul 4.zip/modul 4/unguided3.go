package main

import "fmt"

// Prosedur untuk mencetak deret berdasarkan aturan yang diberikan
func cetakDeret(n int) {
	// Cetak nilai awal
	fmt.Print(n)

	// Lanjutkan sampai n menjadi 1
	for n != 1 {
		if n%2 == 0 {
			n = n / 2
		} else {
			n = 3*n + 1
		}
		// Cetak setiap suku deret, dipisahkan dengan spasi
		fmt.Print(" ", n)
	}
	fmt.Println()
}

func main() {
	var n int
	// Input bilangan bulat positif yang lebih kecil dari 1000000
	fmt.Scan(&n)

	// Panggil prosedur untuk mencetak deret
	cetakDeret(n)
}
